# 🐍 Python Programming Lab — VAC26601

**Gulzar Institute of Engineering and Technology**
B.Tech 6th Semester | JAN–JUNE 2026
Department of Artificial Intelligence and Emerging Technologies
**Faculty:** Mr. Shashank Jha (Assistant Professor)

---

## 📋 List of Experiments

| No. | Experiment | File |
|-----|-----------|------|
| 1  | Install Python and Verify Installation | [exp1_install_verify.py](exp1_install_verify.py) |
| 2  | Print Welcome Message (Comments & Indentation) | [exp2_welcome_message.py](exp2_welcome_message.py) |
| 3  | Personalized Greeting Program (User Input) | [exp3_personalized_greeting.py](exp3_personalized_greeting.py) |
| 4  | Identify and Correct Syntax/Indentation Errors | [exp4_identify_correct_errors.py](exp4_identify_correct_errors.py) |
| 5  | Largest of Three Numbers (Conditional Statements) | [exp5_largest_of_three.py](exp5_largest_of_three.py) |
| 6  | Menu Driven Calculator (if-elif-else) | [exp6_calculator.py](exp6_calculator.py) |
| 7  | Fibonacci Series using Loops | [exp7_fibonacci.py](exp7_fibonacci.py) |
| 8  | Prime Number Check | [exp8_prime_check.py](exp8_prime_check.py) |
| 9  | Simple Interest and Compound Interest | [exp9_simple_compound_interest.py](exp9_simple_compound_interest.py) |
| 10 | CRUD Operations on a List (Student Marks) | [exp10_crud_list.py](exp10_crud_list.py) |
| 11 | Employee Dictionary (ID, Name, Salary) | [exp11_employee_dictionary.py](exp11_employee_dictionary.py) |
| 12 | Search Employee Details by ID | [exp12_search_employee.py](exp12_search_employee.py) |
| 13 | Sort Employee Records by Salary | [exp13_sort_employees.py](exp13_sort_employees.py) |
| 14 | Remove Duplicates from a List using Sets | [exp14_remove_duplicates.py](exp14_remove_duplicates.py) |
| 15 | Count Vowels, Consonants, Digits & Special Chars | [exp15_character_counter.py](exp15_character_counter.py) |
| 16 | Copy Content from One File to Another | [exp16_file_copy.py](exp16_file_copy.py) |
| 17 | Division by Zero — Exception Handling | [exp17_exception_handling.py](exp17_exception_handling.py) |
| 18 | Count Lines and Words in a Text File | [exp18_count_lines_words.py](exp18_count_lines_words.py) |
| 19 | Simple Log File Writer | [exp19_log_file_writer.py](exp19_log_file_writer.py) |
| 20 | Create and Activate a Virtual Environment | [exp20_virtual_environment.py](exp20_virtual_environment.py) |
| 21 | Install NumPy, Pandas, and Matplotlib | [exp21_install_libraries.py](exp21_install_libraries.py) |
| 22 | Display All Installed Python Packages | [exp22_display_packages.py](exp22_display_packages.py) |

---

## 🛠️ Requirements

- Python 3.x
- pip (Python package manager)
- Libraries: `numpy`, `pandas`, `matplotlib` (for Exp 21 & 22)

Install required libraries:
```bash
pip install numpy pandas matplotlib
```

---

## 🚀 How to Run

1. Clone this repository:
```bash
git clone https://github.com/YOUR_USERNAME/Python_Lab_VAC26601.git
cd Python_Lab_VAC26601
```

2. Run any experiment:
```bash
python exp1_install_verify.py
python exp5_largest_of_three.py
```

---

## 💻 Lab Setup (Hardware & Software)

| Component | Details |
|-----------|---------|
| OS | Windows 7 Ultimate (32-bit) |
| Python | Python 3.x |
| IDE | VS Code / IDLE / Jupyter Notebook |
| Package Manager | pip |
| Libraries | NumPy, Pandas, Matplotlib, Flask, SQLite |

---

## 📂 Repository Structure

```
Python_Lab_VAC26601/
│
├── exp1_install_verify.py
├── exp2_welcome_message.py
├── exp3_personalized_greeting.py
├── exp4_identify_correct_errors.py
├── exp5_largest_of_three.py
├── exp6_calculator.py
├── exp7_fibonacci.py
├── exp8_prime_check.py
├── exp9_simple_compound_interest.py
├── exp10_crud_list.py
├── exp11_employee_dictionary.py
├── exp12_search_employee.py
├── exp13_sort_employees.py
├── exp14_remove_duplicates.py
├── exp15_character_counter.py
├── exp16_file_copy.py
├── exp17_exception_handling.py
├── exp18_count_lines_words.py
├── exp19_log_file_writer.py
├── exp20_virtual_environment.py
├── exp21_install_libraries.py
├── exp22_display_packages.py
└── README.md
```

---

*Python Programming Lab | VAC26601 | Gulzar Institute of Engineering and Technology*
