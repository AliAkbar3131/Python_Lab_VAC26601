# Experiment 22: Display All Installed Packages
# VAC26601 - Python Programming Lab
# Gulzar Institute of Engineering and Technology

# AIM: To write a Python program to display all installed packages.

# METHOD 1: Using pkg_resources
import pkg_resources

print("=" * 45)
print(f"{'Package Name':<30} {'Version'}")
print("=" * 45)

installed_packages = sorted(pkg_resources.working_set, key=lambda p: p.project_name.lower())

for p in installed_packages:
    print(f"{p.project_name:<30} {p.version}")

print("=" * 45)
print(f"Total packages installed: {len(installed_packages)}")

# SAMPLE OUTPUT:
# =============================================
# Package Name                   Version
# =============================================
# matplotlib                     3.8.0
# numpy                          1.26.0
# pandas                         2.1.0
# pip                            23.3.1
# ...
# =============================================
# Total packages installed: 42

# Result: Program executed successfully.

# -------------------------------------------------------
# TERMINAL COMMAND alternative (Practice):
# -------------------------------------------------------
#   pip list
#   pip list --format=columns
