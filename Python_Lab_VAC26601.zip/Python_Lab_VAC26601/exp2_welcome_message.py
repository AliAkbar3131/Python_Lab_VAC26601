# Experiment 2: Print Welcome Message
# VAC26601 - Python Programming Lab
# Gulzar Institute of Engineering and Technology

# AIM: To learn comments and indentation.

# This is a single-line comment
"""
This is a multi-line comment (docstring).
Program to print a welcome message demonstrating
proper comments and indentation.
"""

# Printing the welcome message
print("Welcome to Gulzar Group of Institutions")

# OUTPUT:
# Welcome to Gulzar Group of Institutions

# Result: Program executed successfully.
