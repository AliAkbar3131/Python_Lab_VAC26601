# Experiment 12: Search Employee by ID
# VAC26601 - Python Programming Lab
# Gulzar Institute of Engineering and Technology

# AIM: To search employee details using employee ID.

emps = {101: "Rahul", 102: "Aman", 103: "Neha"}

emp_id = int(input("Enter Employee ID: "))
result = emps.get(emp_id, "Employee Not Found")
print("Employee Name:", result)

# SAMPLE OUTPUT:
# Enter Employee ID: 101
# Employee Name: Rahul

# Enter Employee ID: 999
# Employee Name: Employee Not Found

# Result: Program executed successfully.
