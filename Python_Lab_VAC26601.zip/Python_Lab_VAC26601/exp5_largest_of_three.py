# Experiment 5: Largest of Three Numbers
# VAC26601 - Python Programming Lab
# Gulzar Institute of Engineering and Technology

# AIM: To implement conditional statements.

a = int(input("Enter first number: "))
b = int(input("Enter second number: "))
c = int(input("Enter third number: "))

if a > b and a > c:
    print("Largest:", a)
elif b > c:
    print("Largest:", b)
else:
    print("Largest:", c)

# SAMPLE OUTPUT:
# Enter first number: 5
# Enter second number: 9
# Enter third number: 3
# Largest: 9

# Result: Largest number calculated successfully.
