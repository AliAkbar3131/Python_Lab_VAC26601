# Experiment 11: Employee Dictionary
# VAC26601 - Python Programming Lab
# Gulzar Institute of Engineering and Technology

# AIM: To create a dictionary storing employee details (ID, Name, Salary).

emp = {"ID": 101, "Name": "Shashank", "Salary": 50000}
print("Employee Details:", emp)
print("ID:", emp["ID"])
print("Name:", emp["Name"])
print("Salary:", emp["Salary"])

# OUTPUT:
# Employee Details: {'ID': 101, 'Name': 'Shashank', 'Salary': 50000}
# ID: 101
# Name: Shashank
# Salary: 50000

# Result: Program executed successfully.

# ---- Practice: Add multiple employees dynamically ----
print("\n--- Multiple Employees ---")
employees = []
n = int(input("How many employees to add? "))
for i in range(n):
    emp_id = int(input("Enter ID: "))
    name = input("Enter Name: ")
    salary = float(input("Enter Salary: "))
    employees.append({"ID": emp_id, "Name": name, "Salary": salary})

for e in employees:
    print(e)
