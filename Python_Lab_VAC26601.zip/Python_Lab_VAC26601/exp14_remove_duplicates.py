# Experiment 14: Remove Duplicates from a List Using Sets
# VAC26601 - Python Programming Lab
# Gulzar Institute of Engineering and Technology

# AIM: To remove duplicate elements from a list using sets.

lst = [1, 2, 2, 3, 4, 4, 5]
print("Original list:", lst)

unique = list(set(lst))
print("List after removing duplicates:", unique)

# OUTPUT:
# Original list: [1, 2, 2, 3, 4, 4, 5]
# List after removing duplicates: [1, 2, 3, 4, 5]
# (Note: order may vary since sets are unordered)

# Result: Program executed successfully.

# ---- Practice: Remove duplicates without using set ----
print("\n--- Without using set ---")
lst2 = [1, 2, 2, 3, 4, 4, 5]
unique2 = []
for item in lst2:
    if item not in unique2:
        unique2.append(item)
print("List after removing duplicates (manual):", unique2)
