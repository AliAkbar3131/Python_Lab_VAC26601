# Experiment 20: Virtual Environment
# VAC26601 - Python Programming Lab
# Gulzar Institute of Engineering and Technology

# AIM: To create and activate a Python virtual environment.

# NOTE: These are terminal/command-line commands, not Python code.
# Run them in your terminal (CMD / PowerShell / Terminal).

# -------------------------------------------------------
# STEP 1: Create a virtual environment named 'myenv'
# -------------------------------------------------------
#   python -m venv myenv

# -------------------------------------------------------
# STEP 2: Activate the virtual environment
# -------------------------------------------------------
#   On Windows:
#       myenv\Scripts\activate
#
#   On Mac/Linux:
#       source myenv/bin/activate

# -------------------------------------------------------
# STEP 3: Verify the environment is active
# -------------------------------------------------------
#   python --version
#   pip list

# -------------------------------------------------------
# STEP 4: Deactivate the virtual environment (Practice)
# -------------------------------------------------------
#   deactivate

# -------------------------------------------------------
# OUTPUT (after activation):
# (myenv) C:\Users\YourName>
# -------------------------------------------------------

# The following Python code checks if running inside a venv:
import sys
import os

def is_virtual_env():
    return (hasattr(sys, 'real_prefix') or
            (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix))

if is_virtual_env():
    print("Running inside a virtual environment.")
    print("Virtual env path:", sys.prefix)
else:
    print("NOT running inside a virtual environment.")
    print("Tip: Create one using: python -m venv myenv")

# Result: Environment created successfully.
