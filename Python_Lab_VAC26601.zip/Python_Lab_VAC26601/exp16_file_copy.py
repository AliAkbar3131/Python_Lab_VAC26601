# Experiment 16: File Copy
# VAC26601 - Python Programming Lab
# Gulzar Institute of Engineering and Technology

# AIM: To copy content from one file to another file.

# First, create a sample source file for demonstration
with open("a.txt", "w") as f:
    f.write("Hello, this is source file a.txt\n")
    f.write("This content will be copied to b.txt\n")
    f.write("Python file handling is easy!\n")

# Copy content from a.txt to b.txt
with open("a.txt", "r") as f1, open("b.txt", "w") as f2:
    f2.write(f1.read())

print("File copied successfully from a.txt to b.txt")

# Verify by reading b.txt
print("\nContent of b.txt:")
with open("b.txt", "r") as f:
    print(f.read())

# OUTPUT:
# File copied successfully from a.txt to b.txt
#
# Content of b.txt:
# Hello, this is source file a.txt
# This content will be copied to b.txt
# Python file handling is easy!

# Result: Program executed successfully.

# ---- Practice: Copy file line by line ----
print("--- Copying line by line ---")
with open("a.txt", "r") as f1, open("c.txt", "w") as f2:
    for line in f1:
        f2.write(line)
print("Line-by-line copy done to c.txt")
