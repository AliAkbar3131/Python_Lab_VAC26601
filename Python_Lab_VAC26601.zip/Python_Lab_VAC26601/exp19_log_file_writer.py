# Experiment 19: Log File Writer
# VAC26601 - Python Programming Lab
# Gulzar Institute of Engineering and Technology

# AIM: To create a simple log file writer using file handling.

import datetime

with open("log.txt", "a") as f:
    msg = input("Enter log message: ")
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    f.write(f"[{timestamp}] {msg}\n")

print("Log message saved to log.txt")

# Verify by reading the log file
print("\nCurrent log file contents:")
with open("log.txt", "r") as f:
    print(f.read())

# SAMPLE OUTPUT:
# Enter log message: Server started successfully
# Log message saved to log.txt
#
# Current log file contents:
# [2026-04-10 10:30:00] Server started successfully

# Result: Program executed successfully.
