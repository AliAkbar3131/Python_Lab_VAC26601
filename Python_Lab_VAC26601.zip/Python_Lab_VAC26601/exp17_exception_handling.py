# Experiment 17: Division Exception Handling
# VAC26601 - Python Programming Lab
# Gulzar Institute of Engineering and Technology

# AIM: To demonstrate division by zero handling using exception handling.

try:
    a = int(input("Enter numerator: "))
    b = int(input("Enter denominator: "))
    result = a / b
    print("Result:", result)
except ZeroDivisionError:
    print("Error: Cannot divide by zero")
except ValueError:
    print("Error: Please enter valid integers")
finally:
    print("Program execution complete.")

# SAMPLE OUTPUT (Normal):
# Enter numerator: 10
# Enter denominator: 2
# Result: 5.0
# Program execution complete.

# SAMPLE OUTPUT (Zero division):
# Enter numerator: 10
# Enter denominator: 0
# Error: Cannot divide by zero
# Program execution complete.

# Result: Program executed successfully.
