# Experiment 3: Personalized Greeting Program
# VAC26601 - Python Programming Lab
# Gulzar Institute of Engineering and Technology

# AIM: To learn user input handling.

# Accepting user's name as input
name = input("Enter your name: ")

# Displaying personalized welcome message
print("Welcome", name)

# SAMPLE OUTPUT:
# Enter your name: Shashank
# Welcome Shashank

# Result: Program accepts input and displays output correctly.
