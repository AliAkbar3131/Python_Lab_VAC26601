# Experiment 10: CRUD Operations on List (Student Marks)
# VAC26601 - Python Programming Lab
# Gulzar Institute of Engineering and Technology

# AIM: To perform CRUD operations on student marks list.

# CREATE - Initialize list with marks
marks = [80, 70, 90]
print("Initial marks:", marks)

# CREATE (Add) - Append a new mark
marks.append(85)
print("After append(85):", marks)

# UPDATE - Modify a mark at index 1
marks[1] = 75
print("After update index 1 to 75:", marks)

# READ - Display all marks
print("All marks (Read):", marks)

# DELETE - Remove a specific mark
marks.remove(90)
print("After remove(90):", marks)

# OUTPUT:
# Initial marks: [80, 70, 90]
# After append(85): [80, 70, 90, 85]
# After update index 1 to 75: [80, 75, 90, 85]
# All marks (Read): [80, 75, 90, 85]
# After remove(90): [80, 75, 85]

# Result: Program executed successfully.
