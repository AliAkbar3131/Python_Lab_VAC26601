# Experiment 6: Menu Driven Calculator
# VAC26601 - Python Programming Lab
# Gulzar Institute of Engineering and Technology

# AIM: To implement if-elif ladder.

print("1. Add")
print("2. Subtract")
print("3. Multiply")
print("4. Divide")

ch = int(input("Enter choice: "))
a = int(input("Enter first number: "))
b = int(input("Enter second number: "))

if ch == 1:
    print("Result:", a + b)
elif ch == 2:
    print("Result:", a - b)
elif ch == 3:
    print("Result:", a * b)
elif ch == 4:
    if b != 0:
        print("Result:", a / b)
    else:
        print("Cannot divide by zero")
else:
    print("Invalid choice")

# SAMPLE OUTPUT:
# 1. Add  2. Subtract  3. Multiply  4. Divide
# Enter choice: 1
# Enter first number: 10
# Enter second number: 5
# Result: 15

# Result: Calculator operations performed successfully.
