# Experiment 9: Simple Interest and Compound Interest
# VAC26601 - Python Programming Lab
# Gulzar Institute of Engineering and Technology

# AIM: To calculate Simple Interest and Compound Interest.

p = float(input("Principal: "))
r = float(input("Rate (%): "))
t = float(input("Time (years): "))

# Simple Interest formula: SI = (P * R * T) / 100
si = (p * r * t) / 100

# Compound Interest formula: CI = P * (1 + R/100)^T - P
ci = p * ((1 + r / 100) ** t) - p

print(f"Simple Interest (SI): {si:.2f}")
print(f"Compound Interest (CI): {ci:.2f}")

# SAMPLE OUTPUT:
# Principal: 1000
# Rate (%): 5
# Time (years): 2
# Simple Interest (SI): 100.00
# Compound Interest (CI): 102.50

# Result: Program executed successfully.
