# Experiment 21: Install Libraries (NumPy, Pandas, Matplotlib)
# VAC26601 - Python Programming Lab
# Gulzar Institute of Engineering and Technology

# AIM: To install NumPy, Pandas, and Matplotlib using pip.

# -------------------------------------------------------
# TERMINAL COMMAND to install all three libraries:
# -------------------------------------------------------
#   pip install numpy pandas matplotlib
#
# To install a specific version (Practice):
#   pip install numpy==1.24.0

# -------------------------------------------------------
# Verify installation by importing:
# -------------------------------------------------------

try:
    import numpy as np
    print(f"NumPy    version: {np.__version__}  ✔ Installed")
except ImportError:
    print("NumPy    - NOT installed. Run: pip install numpy")

try:
    import pandas as pd
    print(f"Pandas   version: {pd.__version__}  ✔ Installed")
except ImportError:
    print("Pandas   - NOT installed. Run: pip install pandas")

try:
    import matplotlib
    print(f"Matplotlib version: {matplotlib.__version__}  ✔ Installed")
except ImportError:
    print("Matplotlib - NOT installed. Run: pip install matplotlib")

# SAMPLE OUTPUT:
# NumPy    version: 1.26.0  ✔ Installed
# Pandas   version: 2.1.0   ✔ Installed
# Matplotlib version: 3.8.0 ✔ Installed

# Result: Libraries installed and verified successfully.
