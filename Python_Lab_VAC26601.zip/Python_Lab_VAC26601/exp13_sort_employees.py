# Experiment 13: Sort Employees by Salary
# VAC26601 - Python Programming Lab
# Gulzar Institute of Engineering and Technology

# AIM: To sort employee records based on salary.

emp = {"Rahul": 50000, "Aman": 40000, "Neha": 60000}

# Sort by salary in ascending order
sorted_emp = sorted(emp.items(), key=lambda x: x[1])
print("Sorted by Salary (Ascending):")
for name, salary in sorted_emp:
    print(f"  {name}: {salary}")

# Sort by salary in descending order (Practice)
sorted_emp_desc = sorted(emp.items(), key=lambda x: x[1], reverse=True)
print("\nSorted by Salary (Descending):")
for name, salary in sorted_emp_desc:
    print(f"  {name}: {salary}")

# OUTPUT:
# Sorted by Salary (Ascending):
#   Aman: 40000
#   Rahul: 50000
#   Neha: 60000
#
# Sorted by Salary (Descending):
#   Neha: 60000
#   Rahul: 50000
#   Aman: 40000

# Result: Program executed successfully.
