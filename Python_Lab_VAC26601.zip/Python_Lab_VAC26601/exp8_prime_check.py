# Experiment 8: Prime Number Check
# VAC26601 - Python Programming Lab
# Gulzar Institute of Engineering and Technology

# AIM: To check whether a number is prime or not.

num = int(input("Enter number: "))

if num > 1:
    for i in range(2, num):
        if num % i == 0:
            print(num, "is Not Prime")
            break
    else:
        print(num, "is Prime")
else:
    print(num, "is Not Prime")

# SAMPLE OUTPUT:
# Enter number: 7
# 7 is Prime

# Enter number: 9
# 9 is Not Prime

# Result: Program executed successfully.
