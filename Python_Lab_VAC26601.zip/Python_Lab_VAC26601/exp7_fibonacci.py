# Experiment 7: Fibonacci Series
# VAC26601 - Python Programming Lab
# Gulzar Institute of Engineering and Technology

# AIM: To generate sequence using loops.

n = int(input("Enter terms: "))
a, b = 0, 1

for i in range(n):
    print(a, end=" ")
    a, b = b, a + b

print()  # newline after series

# SAMPLE OUTPUT:
# Enter terms: 5
# 0 1 1 2 3

# Result: Fibonacci series generated correctly.

# ---- Practice: Using while loop ----
print("\nFibonacci using while loop:")
n2 = int(input("Enter terms: "))
a, b = 0, 1
count = 0
while count < n2:
    print(a, end=" ")
    a, b = b, a + b
    count += 1
print()
