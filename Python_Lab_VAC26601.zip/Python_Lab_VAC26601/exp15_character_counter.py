# Experiment 15: Character Counter
# VAC26601 - Python Programming Lab
# Gulzar Institute of Engineering and Technology

# AIM: To count vowels, consonants, digits, and special characters in a string.

s = input("Enter string: ")

vowels = consonants = digits = special = 0

for ch in s:
    if ch.isalpha():
        if ch.lower() in 'aeiou':
            vowels += 1
        else:
            consonants += 1
    elif ch.isdigit():
        digits += 1
    else:
        special += 1

print(f"Vowels       : {vowels}")
print(f"Consonants   : {consonants}")
print(f"Digits       : {digits}")
print(f"Special Chars: {special}")

# SAMPLE OUTPUT:
# Enter string: Hello World! 123
# Vowels       : 3
# Consonants   : 7
# Digits       : 3
# Special Chars: 3

# Result: Program executed successfully.
