# Experiment 4: Identify and Correct Errors
# VAC26601 - Python Programming Lab
# Gulzar Institute of Engineering and Technology

# AIM: To understand syntax and indentation errors.

# FAULTY CODE (with intentional errors):
# if True:
# print("Hello")        <-- IndentationError: expected an indented block

# CORRECTED CODE:
if True:
    print("Program Corrected Successfully")

# OUTPUT:
# Program Corrected Successfully

# Result: Syntax and indentation errors corrected.

# ---- Practice: Intentional Error and Fix ----

# Faulty:
# for i in range(5)     <-- SyntaxError: missing colon
#     print(i)          <-- IndentationError

# Corrected:
for i in range(5):
    print(i)

# OUTPUT:
# 0
# 1
# 2
# 3
# 4
