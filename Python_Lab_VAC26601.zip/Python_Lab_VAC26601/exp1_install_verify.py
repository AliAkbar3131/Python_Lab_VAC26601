# Experiment 1: Install Python and Verify Installation
# VAC26601 - Python Programming Lab
# Gulzar Institute of Engineering and Technology

# AIM: To install Python interpreter and configure development environment.

# Run the following command in terminal to verify Python installation:
# python --version

# To check pip version:
# pip --version

# Expected Output:
# Python 3.x.x  (e.g., Python 3.11.2)
# pip 23.x.x

import sys

print("Python Version:", sys.version)
print("Python Executable:", sys.executable)

# Result: Python installed and verified successfully.
