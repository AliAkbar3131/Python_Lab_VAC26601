# Experiment 18: Count Lines and Words in a File
# VAC26601 - Python Programming Lab
# Gulzar Institute of Engineering and Technology

# AIM: To read a text file and count number of lines and words.

# Create a sample test file for demonstration
with open("test.txt", "w") as f:
    f.write("Python is a popular programming language.\n")
    f.write("It is easy to learn and use.\n")
    f.write("Python supports many libraries.\n")

# Read and count lines, words, and characters
with open("test.txt", "r") as f:
    data = f.read()

line_count = data.count("\n") + 1
word_count = len(data.split())
char_count = len(data)

print("Lines :", line_count)
print("Words :", word_count)
print("Characters:", char_count)

# OUTPUT:
# Lines : 3
# Words : 18
# Characters: 97

# Result: Program executed successfully.
